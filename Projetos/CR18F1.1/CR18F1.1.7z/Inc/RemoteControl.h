/*
 * RemoteControl.h
 *
 *  Created on: Aug 2, 2019
 *      Author: gerry
 */

#ifndef SRC_REMOTECONTROL_H_
#define SRC_REMOTECONTROL_H_

#include "main.h"
#include "spi.h"
#include "gpio.h"

#endif /* SRC_REMOTECONTROL_H_ */
