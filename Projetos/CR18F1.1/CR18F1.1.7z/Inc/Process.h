/*
 * Process.h
 *
 *  Created on: Aug 2, 2019
 *      Author: gerry
 */

#ifndef SRC_PROCESS_H_
#define SRC_PROCESS_H_

#include "main.h"
#include "fifo.h"

fifo_t RS485FifoQueue;

void ProcessPeriodic(void);
void ProcessInit(void);
void StartConversion(void);

#endif /* SRC_PROCESS_H_ */

